/**
 * 
 */
/**
 * 
 */
module sprint0 {
	requires org.junit.jupiter.api;
}